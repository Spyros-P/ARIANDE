#ifndef _ZEPHYR_COMMIT_H_
#define _ZEPHYR_COMMIT_H_

/*  values come from cmake/version.cmake
 * BUILD_COMMIT related  values will be 'git rev-parse',
 * alternatively user defined BUILD_VERSION.
 */

#define ZEPHYR_COMMIT                   0bc3393fb112
#define ZEPHYR_COMMIT_STRING            "0bc3393fb112"

#endif /* _ZEPHYR_COMMIT_H_ */
