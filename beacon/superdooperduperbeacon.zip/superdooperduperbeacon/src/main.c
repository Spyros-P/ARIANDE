#include <zephyr/types.h>
#include <stddef.h>
#include <zephyr/sys/printk.h>
#include <zephyr/sys/util.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/kernel.h>  // For k_timer 
#include <zephyr/drivers/counter.h>
#include <zephyr/device.h>
#include <bluetooth/scan.h>

#include <zephyr/bluetooth/hci.h>// /* main.c - Application main entry point */
#include <zephyr/bluetooth/hci_vs.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/bluetooth/uuid.h> //extra

#define DEVICE_NAME CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)
#define BT_TIMEOUT_MAX 100
#define BT_TIMEOUT_MIN 3

#define ALARM_CHANNEL_ID 0
#define TIMER DT_NODELABEL(rtc2)

#define MAX_SLEEP_DUR 10000
#define MIN_SLEEP_DUR 1000
#define MIN_SCAN_WINDOW 18
#define MAX_SCAN_WINDOW 160

#define SLEEP_TIMEOUT 5000000


// Define limits for the intervals  => Range: 0x0020 to 0x4000
#define MIN_INTERVAL_LIMIT 0x0030  // Lower limit  ( 33 ms to 126 ms  NOW)  // BLE_GAP_ADV_INTERVAL_MIN 
#define MAX_INTERVAL_LIMIT 0x00F0  // Upper limit

/* adv model parameters */
extern int current_min_interval;
extern int current_max_interval;
extern int Tx_id;
extern bool tx_on;

/* Observer model parameters*/
uint16_t scan_interval = (uint16_t) 96; // 60ms
uint16_t scan_window = (uint16_t) 96; // 60ms

uint16_t scan_interval_max = (uint16_t) 160; // 100 ms
uint16_t scan_window_max = (uint16_t) 160; // 100 ms
uint16_t scan_timeout_max = (uint16_t) 360; // 3600 ms
extern int no_packets;

uint64_t counter_timeout = 2000000; // 2s
int sleep_dur = 4000; // 4s
int previous_norm=-1;

// advertise functions //
void adv_start();
void adv_reset();
void adv_stop();

// Observer function //
int  observer_start(uint16_t interval, uint16_t window);
void observer_stop();
void scan_reset(uint16_t interval, uint16_t window); 

const struct device *const counter_dev = DEVICE_DT_GET(TIMER);
struct counter_alarm_cfg alarm_cfg;

static void counter_interrupt_fn(const struct device *counter_dev, uint8_t chan_id, uint32_t ticks, void *user_data);

static void sleep_work_handler(struct k_work *work)
{
    k_sleep(K_MSEC(sleep_dur));
    adv_reset();
    scan_reset(scan_interval, scan_window);
    counter_timeout = SLEEP_TIMEOUT;

    alarm_cfg.flags = 0;
    alarm_cfg.ticks = counter_us_to_ticks(counter_dev, counter_timeout);
    alarm_cfg.callback = counter_interrupt_fn;
    alarm_cfg.user_data = &alarm_cfg;


    // alarm_cfg.ticks = counter_us_to_ticks(counter_dev, counter_timeout);

    int err = counter_set_channel_alarm(counter_dev, ALARM_CHANNEL_ID, &alarm_cfg);
    if (err != 0) {
        printk("Alarm could not be set\n");
    }
}

K_WORK_DEFINE(sleep_work, sleep_work_handler);

static void counter_interrupt_fn(const struct device *counter_dev,
				      uint8_t chan_id, uint32_t ticks,
				      void *user_data)
{

    	struct counter_alarm_cfg *config = user_data;

		printk("Counter interrupt\n");

        int packet_time = (int)((counter_timeout / (scan_interval + scan_window)) * scan_window); 
        int norm_packets = (int)(no_packets * 1000000 / packet_time);  

        printk("No of packets %d Packet time %d Norm packets %d\n", no_packets, packet_time, norm_packets);

        if (previous_norm == -1) {
            previous_norm = norm_packets;
        }
       
        if (norm_packets == 0)
        {
            if (previous_norm == 0) 
            {
                sleep_dur += 0.1*sleep_dur;
                if (sleep_dur >= MAX_SLEEP_DUR) sleep_dur = MAX_SLEEP_DUR;
            }
            observer_stop(); // Stop scanning
            adv_stop(); // Stop advertising
            k_work_submit(&sleep_work);
            // adv_reset();
            // scan_reset(scan_interval, scan_window);
        }
        else
        {   
            if (previous_norm == 0) 
            {
                scan_window -= 0.1*scan_window; 
                if (scan_window <= MIN_SCAN_WINDOW) scan_window = MIN_SCAN_WINDOW;
                scan_reset(scan_interval, scan_window);
                counter_timeout += 0.1 * counter_timeout;

            }
            else if(norm_packets != previous_norm)
            {  
                printk("Min interval %d Max interval %d\n", current_min_interval, current_max_interval);  
                sleep_dur = MIN_SLEEP_DUR; // TODO: Do that after an amount of consecutive non zero packets scanned
                float percentage = (norm_packets - previous_norm)/previous_norm;
                current_min_interval -= (int)(percentage*current_min_interval);
                current_max_interval -= (int)(percentage*current_max_interval);

                if (current_min_interval < MIN_INTERVAL_LIMIT) {
                    current_min_interval = MIN_INTERVAL_LIMIT;
                    current_max_interval = MIN_INTERVAL_LIMIT*1.2;
                }

                if (current_max_interval > MAX_INTERVAL_LIMIT) {
                    current_max_interval = MAX_INTERVAL_LIMIT;
                    current_min_interval = MAX_INTERVAL_LIMIT*0.8;
                }

                printk("Min interval %d Max interval %d\n", current_min_interval, current_max_interval);

                if (percentage != 0) scan_window += (percentage > 0 ? -0.1 : 0.1) * scan_window;
                if (scan_window <= MIN_SCAN_WINDOW) scan_window = MIN_SCAN_WINDOW;
                if (scan_window >= MAX_SCAN_WINDOW) scan_window = MAX_SCAN_WINDOW;

                counter_timeout -= (int)(percentage * counter_timeout); // Check it also with += 

                adv_reset();
                scan_reset(scan_interval,scan_window);
            }

            alarm_cfg.flags = 0;
            alarm_cfg.ticks = counter_us_to_ticks(counter_dev, counter_timeout);
            alarm_cfg.callback = counter_interrupt_fn;
            alarm_cfg.user_data = &alarm_cfg;


            // alarm_cfg.ticks = counter_us_to_ticks(counter_dev, counter_timeout);

            int err = counter_set_channel_alarm(counter_dev, ALARM_CHANNEL_ID, &alarm_cfg);
            if (err != 0) {
                printk("Alarm could not be set\n");
            }

        }

        previous_norm = norm_packets;

        no_packets = 0;
                
} 

/* Bluetooth ready callback */

static void bt_ready(int err)
{
    if (err) {
        printk("Bluetooth init failed (err %d)\n", err);
        return;
    }

    printk("Bluetooth initialized\n");

    (void)observer_start(scan_interval, scan_window);

    adv_start();
}

int main(void)
{
  //  const struct device *const counter_dev = DEVICE_DT_GET(TIMER);
    int err;

    printk("Starting Beacon DION Demo\n");

    if (!device_is_ready(counter_dev)) {
		printk("device not ready.\n");
		return 0;
	}

    counter_start(counter_dev);

	alarm_cfg.flags = 0;
	alarm_cfg.ticks = counter_us_to_ticks(counter_dev, counter_timeout);
	alarm_cfg.callback = counter_interrupt_fn;
	alarm_cfg.user_data = &alarm_cfg;

    err = counter_set_channel_alarm(counter_dev, ALARM_CHANNEL_ID, &alarm_cfg); 

	if (-EINVAL == err) {
		printk("Alarm settings invalid\n");
	} else if (-ENOTSUP == err) {
		printk("Alarm setting request not supported\n");
	} else if (err != 0) {
		printk("Error\n");
	}

    /* Initialize the Bluetooth Subsystem */
    err = bt_enable(bt_ready);
    if (err) {
        printk("Bluetooth init failed (err %d)\n", err);
    }  

    return 0;
}